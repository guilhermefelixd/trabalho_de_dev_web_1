# Catálogo de Filmes — Materialize CSS

Projeto adaptado para a atividade de framework CSS.

## Entidades

- Filme
- Artista
- Ficha Técnica
- Diretor

## Telas

Cada entidade possui:

- Cadastrar
- Listar Todos
- Detalhar

## Relacionamentos

- Diretor 1:N Filme
- Filme 1:N Ficha Técnica
- Artista 1:N Ficha Técnica

## Tecnologias

- Node.js
- Express
- Sequelize
- SQLite
- Handlebars
- Materialize CSS

## Execução

1. Abra a pasta do projeto no VS Code.
2. Execute `npm install` para instalar as dependências.
3. Execute `npm start`.
4. Acesse `http://localhost:3000`.

O banco SQLite é criado/sincronizado automaticamente pelo Sequelize.
