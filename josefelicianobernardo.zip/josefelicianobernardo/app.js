const express = require('express');
const fs = require('fs');
const path = require('path');
const Handlebars = require('handlebars');
const methodOverride = require('method-override');

const sequelize = require('./config/jog');
const Filme = require('./models/filme.models');
const Artista = require('./models/artista.models');
const FichaTecnica = require('./models/fichaTecnica.models');
const Diretor = require('./models/diretor.models');

const app = express();

app.use(methodOverride('_method'));
app.use(express.urlencoded({ extended: true }));
app.use(express.json());

app.engine('handlebars', (filePath, options, callback) => {
    fs.readFile(filePath, 'utf8', (erro, templateSource) => {
        if (erro) return callback(erro);

        try {
            const template = Handlebars.compile(templateSource);
            const body = template(options);
            const layoutPath = path.join(__dirname, 'views', 'layouts', 'main.handlebars');

            fs.readFile(layoutPath, 'utf8', (layoutErro, layoutSource) => {
                if (layoutErro) return callback(layoutErro);
                try {
                    const layout = Handlebars.compile(layoutSource);
                    callback(null, layout({ ...options, body }));
                } catch (erroLayout) {
                    callback(erroLayout);
                }
            });
        } catch (erroTemplate) {
            callback(erroTemplate);
        }
    });
});

app.set('views', path.join(__dirname, 'views'));
app.set('view engine', 'handlebars');
app.use('/css', express.static(path.join(__dirname, 'css')));
app.use('/js', express.static(path.join(__dirname, 'js')));
app.use('/img', express.static(path.join(__dirname, 'img')));
app.use('/materialize', express.static(path.join(__dirname, 'node_modules', 'materialize-css', 'dist')));

// Relacionamentos
Diretor.hasMany(Filme, { foreignKey: 'diretorId' });
Filme.belongsTo(Diretor, { foreignKey: 'diretorId' });

Filme.hasMany(FichaTecnica, { foreignKey: 'filmeId' });
FichaTecnica.belongsTo(Filme, { foreignKey: 'filmeId' });

Artista.hasMany(FichaTecnica, { foreignKey: 'artistaId' });
FichaTecnica.belongsTo(Artista, { foreignKey: 'artistaId' });

// Página inicial
app.get('/', (req, res) => {
    res.render('home', { titulo: 'Catálogo de Filmes' });
});

// ================= FILMES =================
app.get('/filmes', async (req, res) => {
    try {
        const filmes = await Filme.findAll({ include: [Diretor], order: [['nome', 'ASC']] });
        res.render('filmes', { titulo: 'Filmes', filmes: filmes.map(f => f.toJSON()) });
    } catch (erro) {
        console.error(erro);
        res.status(500).send('Erro ao listar filmes.');
    }
});

app.get('/filmes/cadastrar', async (req, res) => {
    const diretores = await Diretor.findAll({ raw: true, order: [['nome', 'ASC']] });
    res.render('cadastrarFilme', { titulo: 'Cadastrar Filme', diretores });
});

app.post('/filmes', async (req, res) => {
    try {
        await Filme.create({
            nome: req.body.nome,
            ano: req.body.ano,
            diretorId: req.body.diretorId,
            sinopse: req.body.sinopse
        });
        res.redirect('/filmes');
    } catch (erro) {
        console.error(erro);
        res.status(500).send('Erro ao cadastrar filme.');
    }
});

app.get('/filmes/:id', async (req, res) => {
    try {
        const filme = await Filme.findByPk(req.params.id, {
            include: [Diretor, { model: FichaTecnica, include: [Artista] }]
        });
        if (!filme) return res.status(404).send('Filme não encontrado.');
        res.render('detalharFilme', { titulo: 'Detalhes do Filme', filme: filme.toJSON() });
    } catch (erro) {
        console.error(erro);
        res.status(500).send('Erro ao detalhar filme.');
    }
});

// ================= DIRETORES =================
app.get('/diretores', async (req, res) => {
    try {
        const diretores = await Diretor.findAll({ raw: true, order: [['nome', 'ASC']] });
        res.render('diretores', { titulo: 'Diretores', diretores });
    } catch (erro) {
        console.error(erro);
        res.status(500).send('Erro ao listar diretores.');
    }
});

app.get('/diretores/cadastrar', (req, res) => {
    res.render('cadastrarDiretor', { titulo: 'Cadastrar Diretor' });
});

app.post('/diretores', async (req, res) => {
    try {
        await Diretor.create({ nome: req.body.nome, nacionalidade: req.body.nacionalidade });
        res.redirect('/diretores');
    } catch (erro) {
        console.error(erro);
        res.status(500).send('Erro ao cadastrar diretor.');
    }
});

app.get('/diretores/:id', async (req, res) => {
    try {
        const diretor = await Diretor.findByPk(req.params.id, { include: [Filme] });
        if (!diretor) return res.status(404).send('Diretor não encontrado.');
        res.render('detalharDiretor', { titulo: 'Detalhes do Diretor', diretor: diretor.toJSON() });
    } catch (erro) {
        console.error(erro);
        res.status(500).send('Erro ao detalhar diretor.');
    }
});

// ================= ARTISTAS =================
app.get('/artistas', async (req, res) => {
    try {
        const artistas = await Artista.findAll({ raw: true, order: [['nome', 'ASC']] });
        res.render('artistas', { titulo: 'Artistas', artistas });
    } catch (erro) {
        console.error(erro);
        res.status(500).send('Erro ao listar artistas.');
    }
});

app.get('/artistas/cadastrar', (req, res) => {
    res.render('cadastrarArtista', { titulo: 'Cadastrar Artista' });
});

app.post('/artistas', async (req, res) => {
    try {
        await Artista.create({ nome: req.body.nome, anoNascimento: req.body.anoNascimento || null });
        res.redirect('/artistas');
    } catch (erro) {
        console.error(erro);
        res.status(500).send('Erro ao cadastrar artista.');
    }
});

app.get('/artistas/:id', async (req, res) => {
    try {
        const artista = await Artista.findByPk(req.params.id, {
            include: [{ model: FichaTecnica, include: [Filme] }]
        });
        if (!artista) return res.status(404).send('Artista não encontrado.');
        res.render('detalharArtista', { titulo: 'Detalhes do Artista', artista: artista.toJSON() });
    } catch (erro) {
        console.error(erro);
        res.status(500).send('Erro ao detalhar artista.');
    }
});

// ================= FICHAS TÉCNICAS =================
app.get('/fichas-tecnicas', async (req, res) => {
    try {
        const fichas = await FichaTecnica.findAll({ include: [{ model: Filme, include: [Diretor] }, Artista], order: [['id', 'ASC']] });
        res.render('fichasTecnicas', { titulo: 'Fichas Técnicas', fichas: fichas.map(f => f.toJSON()) });
    } catch (erro) {
        console.error(erro);
        res.status(500).send('Erro ao listar fichas técnicas.');
    }
});

app.get('/fichas-tecnicas/cadastrar', async (req, res) => {
    const [filmes, artistas] = await Promise.all([
        Filme.findAll({ raw: true, order: [['nome', 'ASC']] }),
        Artista.findAll({ raw: true, order: [['nome', 'ASC']] })
    ]);
    res.render('cadastrarFichaTecnica', { titulo: 'Cadastrar Ficha Técnica', filmes, artistas });
});

app.post('/fichas-tecnicas', async (req, res) => {
    try {
        await FichaTecnica.create({
            funcao: req.body.funcao,
            filmeId: req.body.filmeId,
            artistaId: req.body.artistaId
        });
        res.redirect('/fichas-tecnicas');
    } catch (erro) {
        console.error(erro);
        res.status(500).send('Erro ao cadastrar ficha técnica.');
    }
});

app.get('/fichas-tecnicas/:id', async (req, res) => {
    try {
        const ficha = await FichaTecnica.findByPk(req.params.id, { include: [{ model: Filme, include: [Diretor] }, Artista] });
        if (!ficha) return res.status(404).send('Ficha técnica não encontrada.');
        res.render('detalharFichaTecnica', { titulo: 'Detalhes da Ficha Técnica', ficha: ficha.toJSON() });
    } catch (erro) {
        console.error(erro);
        res.status(500).send('Erro ao detalhar ficha técnica.');
    }
});

async function conectarBD() {
    try {
        await sequelize.sync();
        console.log('Conexão com o banco de dados estabelecida com sucesso!');
    } catch (erro) {
        console.error('Erro ao conectar com o banco:', erro);
    }
}

conectarBD();

app.listen(3000, () => console.log('Servidor executando em http://localhost:3000'));
