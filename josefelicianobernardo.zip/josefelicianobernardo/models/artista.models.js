const { DataTypes } = require('sequelize');
const sequelize = require('../config/jog');

const Artista = sequelize.define('Artista', {
    id: { type: DataTypes.INTEGER, primaryKey: true, autoIncrement: true },
    nome: { type: DataTypes.STRING, allowNull: false },
    anoNascimento: { type: DataTypes.INTEGER, allowNull: true }
}, { tableName: 'artistas' });

module.exports = Artista;
