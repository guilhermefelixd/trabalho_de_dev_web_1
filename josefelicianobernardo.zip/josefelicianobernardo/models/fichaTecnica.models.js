const { DataTypes } = require('sequelize');
const sequelize = require('../config/jog');

const FichaTecnica = sequelize.define('FichaTecnica', {
    id: { type: DataTypes.INTEGER, primaryKey: true, autoIncrement: true },
    funcao: { type: DataTypes.STRING, allowNull: false },
    filmeId: { type: DataTypes.INTEGER, allowNull: false },
    artistaId: { type: DataTypes.INTEGER, allowNull: false }
}, { tableName: 'fichas_tecnicas' });

module.exports = FichaTecnica;
