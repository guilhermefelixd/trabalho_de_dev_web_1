const { DataTypes } = require('sequelize');
const sequelize = require('../config/jog');

const Filme = sequelize.define('Filme', {
    id: { type: DataTypes.INTEGER, primaryKey: true, autoIncrement: true },
    nome: { type: DataTypes.STRING, allowNull: false },
    ano: { type: DataTypes.INTEGER, allowNull: false },
    diretorId: { type: DataTypes.INTEGER, allowNull: false },
    sinopse: { type: DataTypes.TEXT, allowNull: true }
}, { tableName: 'filmes' });

module.exports = Filme;
