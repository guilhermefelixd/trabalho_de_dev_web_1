const { DataTypes } = require('sequelize');
const sequelize = require('../config/jog');

const Diretor = sequelize.define('Diretor', {
    id: { type: DataTypes.INTEGER, primaryKey: true, autoIncrement: true },
    nome: { type: DataTypes.STRING, allowNull: false },
    nacionalidade: { type: DataTypes.STRING, allowNull: true }
}, { tableName: 'diretores' });

module.exports = Diretor;
